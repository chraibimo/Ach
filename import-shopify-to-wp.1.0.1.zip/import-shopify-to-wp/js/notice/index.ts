import {Notice} from "./Notice";

new Notice(document.querySelector('.s2wp-notice'));

